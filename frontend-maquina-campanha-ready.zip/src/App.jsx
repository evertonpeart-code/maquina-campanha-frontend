import React, { useState } from 'react'
import Header from './components/Header'
import './index.css'

export default function App() {
  const [darkMode, setDarkMode] = useState(false)

  return (
    <div className={darkMode ? 'dark bg-gray-900 text-white min-h-screen' : 'bg-white text-gray-900 min-h-screen'}>
      <Header darkMode={darkMode} toggle={() => setDarkMode(d => !d)} />
      <main className="p-6 max-w-4xl mx-auto">
        <section className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-6 shadow">
          <h1 className="text-2xl font-semibold mb-2">🚀 Máquina de Campanha IA</h1>
          <p className="text-gray-600 dark:text-gray-300 mb-4">Crie campanhas Google Ads em CSV com SEO e A/B tests. Conecte com a API do OpenRouter no backend.</p>

          <div className="flex gap-3">
            <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded">Gerar Campanha</button>
            <button className="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded dark:bg-gray-700 dark:hover:bg-gray-600">Importar CSV</button>
          </div>
        </section>
      </main>

      <footer className="text-center text-sm p-4 text-gray-500 dark:text-gray-400">
        &copy; {new Date().getFullYear()} Máquina de Campanha IA
      </footer>
    </div>
  )
}
