import React from 'react'

export default function Header({ darkMode, toggle }) {
  return (
    <header className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-white dark:bg-gray-800 rounded flex items-center justify-center shadow">
          <span className="font-bold text-blue-600">MA</span>
        </div>
        <div>
          <div className="font-semibold">Máquina de Campanha</div>
          <div className="text-xs text-gray-500 dark:text-gray-400">Painel</div>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <button onClick={toggle} className="px-3 py-1 rounded bg-blue-600 text-white hover:bg-blue-700">
          {darkMode ? '☀️ Claro' : '🌙 Escuro'}
        </button>
      </div>
    </header>
)
}
