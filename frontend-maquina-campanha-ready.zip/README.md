# Frontend - Máquina de Campanha IA (ready)

Estrutura pronta para subir no GitHub e deploy no Render (Static Site).

**Para subir no GitHub (via Upload):**
1. Acesse o repositório `maquina-campanha-frontend`.
2. Use _Add file → Upload files_ e arraste os arquivos (mantenha a estrutura).
3. Commit direto na branch `main`.

**Para deploy no Render:**
- Create → Static Site
- Build Command: `npm install && npm run build`
- Publish Directory: `dist`
